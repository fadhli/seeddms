DROP TABLE IF EXISTS `tblACLs`;

DROP TABLE IF EXISTS `tblDocumentApproveLog`;
DROP TABLE IF EXISTS `tblDocumentApprovers`;

DROP TABLE IF EXISTS `tblDocumentReviewLog`;
DROP TABLE IF EXISTS `tblDocumentReviewers`;

DROP TABLE IF EXISTS `tblDocumentStatusLog`;
DROP TABLE IF EXISTS `tblDocumentStatus`;

DROP TABLE IF EXISTS `tblDocumentAttributes`;
DROP TABLE IF EXISTS `tblDocumentContentAttributes`;
DROP TABLE IF EXISTS `tblDocumentContent`;
DROP TABLE IF EXISTS `tblDocumentLinks`;
DROP TABLE IF EXISTS `tblDocumentFiles`;
DROP TABLE IF EXISTS `tblDocumentLocks`;
DROP TABLE IF EXISTS `tblDocumentCategory`;
DROP TABLE IF EXISTS `tblDocuments`;

DROP TABLE IF EXISTS `tblFolderAttributes`;
DROP TABLE IF EXISTS `tblFolders`;

DROP TABLE IF EXISTS `tblAttributeDefinitions`;

DROP TABLE IF EXISTS `tblGroupMembers`;
DROP TABLE IF EXISTS `tblGroups`;

DROP TABLE IF EXISTS `tblKeywords`;
DROP TABLE IF EXISTS `tblKeywordCategories`;

DROP TABLE IF EXISTS `tblCategory`;

DROP TABLE IF EXISTS `tblNotify`;
DROP TABLE IF EXISTS `tblSessions`;

DROP TABLE IF EXISTS `tblUserImages`;
DROP TABLE IF EXISTS `tblUserPasswordRequest`;
DROP TABLE IF EXISTS `tblUserPasswordHistory`;
DROP TABLE IF EXISTS `tblUsers`;

DROP TABLE IF EXISTS `tblDirPath`;
DROP TABLE IF EXISTS `tblPathList`;

DROP TABLE IF EXISTS `tblMandatoryReviewers`;
DROP TABLE IF EXISTS `tblMandatoryApprovers`;

DROP TABLE IF EXISTS `tblEvents`;

DROP TABLE IF EXISTS `tblVersion`;