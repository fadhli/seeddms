BEGIN;

UPDATE tblVersion set major=4, minor=1, subminor=0;

COMMIT;
